<?php

header("Content-Type: application/json; charset=UTF-8");


$object = 
[
    [
        'brand'=> 'BMW',
        'id'=> 1,
        'model'=> 'X1',
        'price'=> 253.000,
        'image_url'=> 'http://localhost/Webbshop/images/Bmw-x1.jpg',
        'description' => "BMW X1 is a great luxury subcompact SUV. 
         This crossover boasts numerous appealing traits, including a large cargo capacity
         and a user-friendly infotainment system. On the performance front, 
         this BMW impresses with its strong engine, zesty handling, and great gas mileage. 
         It does have a few drawbacks, such as some downmarket cabin pieces and a stiff ride, 
         but it’s still an alluring vehicle."
         
    ],
    [
        'brand'=> 'BMW',
        'id'=> 2,
        'model'=> 'X5',
        'price'=> 589.000,
        'image_url'=> 'http://localhost/Webbshop/images/Bmw-x5.jpg',
        'description' => "BMW X5 is one of the best luxury midsize SUVs on the market.
         It delivers a poised ride through corners, and its suspension system easily soaks up bumps in the road. 
         There are multiple powertrains to choose from, all strong, including the brand-new xDrive45e plug-in-hybrid 
         and the performance-oriented M50i and M models. The X5 also has adult-friendly seating and lots of cargo room, 
         but it’s available third row is a tight fit for adults."
        
    ],    
    [
        'brand'=> 'BMW',
        'id'=> 3,
        'model'=> 'X3',
        'price'=> 333.000,
        'image_url'=> 'http://localhost/Webbshop/images/Bmw-x3.jpg',
        'description' => "BMW X3 is a great luxury SUV.
         The X3 has an upscale interior, roomy seating for five passengers, 
         and a large cargo area. It’s comfortable and relaxing to drive day to day, 
         yet still agile and exciting for carving up twisting backroads. 
         Engine options range from a turbocharged four-cylinder to a plug-in hybrid
         and a twin-turbo six-cylinder that each scoot the X3 up to speed confidently."
        
    ],    
    [
        'brand'=> 'Volvo',
        'id'=> 4,
        'model'=> 'XC40',
        'price'=> 350.000,
        'image_url'=> 'http://localhost/Webbshop/images/Volvo-xc40.jpg',
        'description' => "XC40 is a good luxury subcompact SUV. 
         Both turbocharged engine choices deliver solid acceleration,
         and the XC40 offers a pleasant ride with fairly spirited handling.
         The cabin has quality materials and a sharp design. 
         Passenger space is good for such a small vehicle. The cargo hold is smaller than many rivals' offerings,
         but it's still very serviceable. The biggest qualm with the XC40's cabin is a somewhat convoluted infotainment system."
        
    ],    
    [
        'brand'=> 'Volvo',
        'id'=> 5,
        'model'=> 'V60',
        'price'=> 356.000,
        'image_url'=> 'http://localhost/Webbshop/images/Volvo-V60.jpg',
        'description' => "V60 is a good wagon, and it's available with either a gas engine or a plug-in-hybrid powertrain. 
         Like most Volvos, the V60 comes standard with a wealth of safety features. 
         Inside, it has adult-friendly seating and a reasonable amount of cargo room. 
         This Volvo also has poised handling, though it isn't as enjoyable to drive as some classmates."
        
    ],    
    [
        'brand'=> 'Mercedes',
        'id'=> 6,
        'model'=> 'G63 Amg Brabus',
        'price'=> 998.000,
        'image_url'=> 'http://localhost/Webbshop/images/G63AMG.Brabus.jpg',
        'description' => "Mercedes-Benz G-Class is a great luxury large SUV.
         This vehicle is well-rounded, with a coddling ride, lavish cabin materials, 
         a high-tech infotainment system, and spacious seats. It has brutish V8 engines, 
         especially in the powerful AMG trim.And with the Brabus trim you get 700HP. It’s also a very capable off-roader, 
         tackling trails, rocks, and water with ease. Just keep an eye on its staggering price tag."
        
    ],    
    [
        'brand'=> 'Ferrari',
        'id'=> 7,
        'model'=> 'F8-Tributo',
        'price'=> 999.999,
        'image_url'=> 'http://localhost/Webbshop/images/Ferrari-F8-Tributo-2020.jpg',
        'description' => "The Ferrari F8 Tributo is the new mid-rear-engined sports car that represents 
         the highest expression of the Prancing Horse’s classic two-seater berlinetta.
         It is a car with unique characteristics and, as its name implies, is an homage 
         to the most powerful V8 in Ferrari history.he F8 Tributo uses the same engine from the 488 Pista,
         a 3.9 L twin-turbocharged V8 engine which has a power output of 720 PS (530 kW; 710 hp)
         and 770 N⋅m (568 lb⋅ft) of torque,[5][6] making it the most powerful conventional 
         V8-powered Ferrari produced to date."
        
    ],    
    [
        'brand'=> 'BMW',
        'id'=> 8,
        'model'=> 'X6',
        'price'=> 658.000,
        'image_url'=> 'http://localhost/Webbshopb/images/Bmw-x6.jpg',
        'description' => "BMW X6 is a decent luxury SUV. The X6 has a high-end interior, 
         comfy seats, lots of standard tech and safety features, and a fairly user-friendly 
         infotainment system. It feels athletic and surefooted to drive on winding roads, 
         and its turbocharged engine lineup provides more than enough power for most situations. 
         The X6 also rates well for predicted reliability."
        
    ],    
    [
        'brand'=> 'BMW',
        'id'=> 9,
        'model'=> 'X7',
        'price'=> 865.000,
        'image_url'=> 'http://localhost/Webbshop/images/Bmw-x7.jpg',
        'description' => "BBMW X7 is a good luxury large SUV. 
         The X7's engine lineup consists of three great turbocharged choices, 
         starting with a capable six-cylinder and followed by two phenomenally powered V8s. 
         Ride and handling are nicely balanced, with a slight propensity toward comfort over outright sportiness."
        
        
    ],    
    [
        'brand'=> 'Audi',
        'id'=> 10,
        'model'=> 'A9',
        'price'=> 996.000,
        'image_url'=> 'http://localhost/Webbshop/images/Audi-A9.jpg', 
        'description' => "Audi’s new ultra-luxurious A9 Coupe will feature 
         an all-electric drivetrain when it goes on sale before 2020 Audi 
         looks set to follow in Tesla’s footsteps and offer its new A9 as a luxurious electric-only model.
         This new car, designed to rival the likes of the Mercedes S-Class Coupe and upcoming BMW 8 Series, 
         will be the third in a series of all-electric vehicles from Audi to go on sale before 2020."
        
    ],
];

class Bilar
{
     
    public $id;
    public $brand;
    public $model;
    public $image_url;
    public $descripion;    
    public $lagersaldo;
	
	public function getBil($id){
		
        $result = array($id => ($this->Bilar[$id]) ? $this->Bilar[$id] : $this->Bilar[1]);
        
		return $result;
	}
}
    $bilararray = array();
    array_push($bilararray,$object);        
    
    $bilar = json_encode($bilararray);
    echo $bilar;
?>