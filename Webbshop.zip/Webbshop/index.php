
 <!DOCTYPE html>

 <?php include_once ('App.php');?>


<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Carshop</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body>
  <div class="container">

    
   
    <header class="jumbotron my-4"> <img src="http://localhost/Webbshop/images/bakgrund.jpg" alt="" width="900" height="400" class="img-fluid">  
      <h1  class="display-3"  >A Warm Welcome!</h1>
      <p class="lead " >Take a look at our cars.</p>
      </div>
  
      </header>

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
      
      <div class ='row'>  </div>
  
        
    

  <?php App:: main(); ?>

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website Mellissia & Sobhan 2021</p>
    </div>

    <!-- /.container -->
  </footer>



</body>

</html>
