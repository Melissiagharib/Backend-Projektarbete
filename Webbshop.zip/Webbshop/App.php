<?php

class App{

    public static $endpoint = "http://localhost/Webbshop/API.php";
    // Min main metod som skall användas på index
	public static function main()
    {
        try {
            $rawData = self::getData();
            self:: viewData ($rawData);
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

	public static function getData()
    {

        $json = @file_get_contents(self::$endpoint);

        if (!$json)
            throw new Exception("Cannot access " . self::$endpoint);

        return json_decode($json, true);
    }

       public static function viewData($array){
      
    {
    


foreach ( $array as $key => $postArray){
    $template = "

    
      <div class='card h-100'>
      <img class='card-img-top' src='' alt=''>
        <div class='card-body'>
          <h4 class='card-title'>Card title</h4>

          <p class='card-text'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque.</p>
        </div>
        </div> 
            <hr>";
        }
    echo $template;
}
}
}


?>
   